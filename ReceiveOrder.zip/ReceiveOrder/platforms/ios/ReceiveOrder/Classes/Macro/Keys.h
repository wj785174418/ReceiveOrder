//
//  Keys.h
//  NativeHtmlTest
//
//  Created by HuayuNanyan on 16/7/4.
//
//

#ifndef Keys_h
#define Keys_h

#define ScreenWidth [UIScreen mainScreen].bounds.size.width
#define ScreenHeight [UIScreen mainScreen].bounds.size.height

#endif /* Keys_h */
