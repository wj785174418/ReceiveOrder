//
//  RegisterController.h
//  ReceiveOrder
//
//  Created by HuayuNanyan on 16/7/28.
//
//

#import <UIKit/UIKit.h>

@interface RegisterController : UIViewController
@property (strong, nonatomic) UIScrollView *scrollView;
@property (copy, nonatomic) NSString *userName;
@end
