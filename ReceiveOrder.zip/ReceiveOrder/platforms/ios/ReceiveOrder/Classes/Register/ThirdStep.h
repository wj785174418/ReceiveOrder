//
//  ThirdStep.h
//  ReceiveOrder
//
//  Created by HuayuNanyan on 16/7/28.
//
//

#import <UIKit/UIKit.h>

@interface ThirdStep : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *welcomeLabel;
@end
