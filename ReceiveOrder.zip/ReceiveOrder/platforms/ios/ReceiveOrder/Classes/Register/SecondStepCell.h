//
//  SecondStepCell.h
//  ReceiveOrder
//
//  Created by HuayuNanyan on 16/7/28.
//
//

#import <UIKit/UIKit.h>

@interface SecondStepCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;

@end
