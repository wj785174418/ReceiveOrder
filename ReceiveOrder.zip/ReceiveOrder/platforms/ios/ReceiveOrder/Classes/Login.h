//
//  ViewController.h
//  ReceiveOrder
//
//  Created by HuayuNanyan on 16/7/25.
//
//

#import <UIKit/UIKit.h>

@interface Login : UIViewController

@end
